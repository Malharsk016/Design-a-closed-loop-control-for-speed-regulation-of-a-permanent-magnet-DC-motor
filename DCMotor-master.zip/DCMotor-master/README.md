# DCMotor
 DCMotor speed control using ATMega32, Simulated in Proteus 
